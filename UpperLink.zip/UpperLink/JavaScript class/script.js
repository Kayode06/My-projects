// let players = ["kayode", "Ronaldo", "Haaland"];
    
//     alert( players[0] ); // kayode
//     alert( players[1] ); // Ronaldo
//     alert( players[2] ); // Haaland

//     alert(players);


    
 
    let arr1 = [1, 2, 3, 4, 5];
    
    let arr2 = new Array(6, 7, 8, 9, 10);
    
  
    let numbers = [5, 15, 25, 30, 10, 18, 22];
    for (let i = 0; i < numbers.length; i++) {
        if (numbers[i] < 20) {
            alert(numbers[i]); // This will alert the numbers less than 20
        }
    }
    
   
    function squareOfLength(arr) {
        return arr.length * arr.length; // Squaring the length of the array
    }
    
    // Example usage:
    let myArray = [1, 2, 3, 4, 5];
    console.log(squareOfLength(myArray)); // This will output: 25